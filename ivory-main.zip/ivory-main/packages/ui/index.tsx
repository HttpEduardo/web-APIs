export {default as Menu} from "./components/menu/menu";
export {default as OnThisPage} from "./components/on-this-page/on-this-page";
export {default as Footer} from "./components/footer/footer";
export {default as Header} from "./components/header/header";
export {default as RouterHead} from "./components/router-head/router-head";
export {default as BreadCrumbs} from "./components/breadcrumbs/breadcrumbs";